#ifndef PROJECT1_KEYSHORTCUTS_H
#define PROJECT1_KEYSHORTCUTS_H

#include <iostream>
#include <SFML/Graphics.hpp>

class KeyShortcuts {
public:
    static bool isUndo();
};

#endif //PROJECT1_KEYSHORTCUTS_H

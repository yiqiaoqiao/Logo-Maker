#ifndef PROJECT1_OBJECTSTATES_H
#define PROJECT1_OBJECTSTATES_H

enum ObjectStates
{
    HIDDEN,
    DISABLE,

    //Add new states above this
    LAST_STATE
};

#endif //PROJECT1_OBJECTSTATES_H
